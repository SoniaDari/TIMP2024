% Four Variable Model with nonlinearity included 

function dydt = fourvariablemodelnondim_nonlinearity(t,y,nx,delta_x,sigma_C,f_max,eta_bar,delta_C,...
    D_F,chi_F,sigma_F,delta_F,D_M,k_M,gamma_M,mu_bar,delta_M,D_P,k_P,gamma_P,delta_P,k_f,gamma_F)

%% Setting up variables (E:ECM, F:fibroblasts, M:MMPs, T:TIMPs)
dCdt = zeros(nx,1);
dFdt = zeros(nx,1);
dMdt = zeros(nx,1);
dPdt = zeros(nx,1);

C = y(1:nx);
F = y(nx+1:2*nx);
M = y(2*nx+1:3*nx);
P = y(3*nx+1:4*nx);

%% No flux BCs
C(1) = (4*C(2)-C(3))/3;
C(nx) = (4*C(nx-1)-C(nx-2))/3;
F(1) = (4*F(2)-F(3))/3;
F(nx) = (4*F(nx-1)-F(nx-2))/3;
M(1) = (4*M(2)-M(3))/3;
M(nx) = (4*M(nx-1)-M(nx-2))/3;
P(1) = (4*P(2)-P(3))/3;
P(nx) = (4*P(nx-1)-P(nx-2))/3;

%% Linear Diffusion
for i = 2:nx-1
    dCdx2(i) = (C(i+1)-2*C(i)+C(i-1))/(delta_x^2);
    dFdx2(i) = (F(i+1)-2*F(i)+F(i-1))/(delta_x^2);
    dMdx2(i) = (M(i+1)-2*M(i)+M(i-1))/(delta_x^2);
    dPdx2(i) = (P(i+1)-2*P(i)+P(i-1))/(delta_x^2);    
end

%% Chemotaxis for F
for i = 1:nx
    FF(i)=F(i)*M(i);
end


for i = 2:nx-1
    F_up(i) = chi_F*(FF(i)+FF(i+1))/2;
    F_down(i) = chi_F*(FF(i)+FF(i-1))/2;
end

for i = 1:nx
    C_fun(i) = 1 - C(i);
end

for i = 2:nx-1
    F_chem(i)  = (F_up(i)*(C_fun(i+1)-C_fun(i)) - F_down(i)*(C_fun(i)-C_fun(i-1)))/(delta_x^2);
end


%% Defining PDEs
for i = 2:nx-1
    dCdt(i) = dCdx2(i) + sigma_C*F(i)*(1-C(i))*(1+f_max*M(i)*exp(1-M(i)))-eta_bar*M(i)*C(i)-delta_C*C(i);
    dFdt(i) = D_F*dFdx2(i) - F_chem(i) + sigma_F*F(i)*(1-F(i))*(1+(k_f*C(i)/(gamma_F+C(i)))) - delta_F*F(i);
    dMdt(i) = D_M*dMdx2(i) + (k_M*F(i))*(1-C(i))/(gamma_M+F(i)) - mu_bar*M(i)*P(i) - delta_M*M(i);
    dPdt(i) = D_P*dPdx2(i) + k_P*F(i)*M(i)/(gamma_P+F(i)) - mu_bar*M(i)*P(i) - delta_P*P(i);
end

dydt = [dCdt;dFdt;dMdt;dPdt];




