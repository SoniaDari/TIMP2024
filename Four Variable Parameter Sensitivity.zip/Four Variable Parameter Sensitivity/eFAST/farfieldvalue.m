function u = farfieldvalue(sigma_C,f_max,eta_bar,delta_C,D_F,chi_F,sigma_F,delta_F,D_M,k_M,gamma_M,...
    mu_bar,delta_M,D_P,k_P,gamma_P,delta_P,k_f,gamma_F)

    q = 0;
    r = 100;
    nx = 100;
    x=linspace(q,r,nx);
    delta_x = x(2)-x(1);
    tspan = linspace(0,20,20);

    C_init = heaviside(3-x);
    F_init = heaviside(3-x);
    M_init = 0.1*exp(-((x-3).^2));
    P_init = 0*ones(1,nx);
    u0 = [C_init F_init M_init P_init];

    [t,u] = ode15s(@(t,y) fourvariablemodelnondim_nonlinearity(t,y,nx,delta_x,...
    sigma_C,f_max,eta_bar,delta_C,D_F,chi_F,sigma_F,delta_F,D_M,k_M,gamma_M,...
    mu_bar,delta_M,D_P,k_P,gamma_P,delta_P,k_f,gamma_F),tspan, u0);
    u = u(20,99);
