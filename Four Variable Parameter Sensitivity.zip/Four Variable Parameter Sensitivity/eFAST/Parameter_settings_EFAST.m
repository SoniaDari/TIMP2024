%% PARAMETER INITIALIZATION
% set up max and mix matrices

pmin=[0.05, 
    0.05, 
    0.05,
    0.05,
    0.05,
    0.05,
    0.05,
    0.05,
    0.05,
    0.05,
    0.05,
    0.05,
    0.05,
    0.05,
    0.05,
    0.05,
    0.05,
    0.05,
    0.05,
    0.05];

                       
pmax=[100,
    100,
    100,
    100,
    100,
    100,
    100,
    100,
    100,
    100,
    1,
    100,
    100,
    100,
    100,
    1,
    100,
    100,
    1,
    100];

% Parameter Labels 
efast_var={'\sigma_C', 'f_{max}', '\overline{\eta}', '\delta_C', 'D_F',...
    'chi_F','\sigma_F','delta_F','D_M','k_M', '\gamma_M','\overline{\mu}',...
    '\delta_M', 'D_P','k_P','\gamma_P', '\delta_P', 'k_f','\gamma_F','dummy'};%,

% PARAMETER BASELINE VALUES
D_c = 0.05882352941*6.12*(10^(-7));
D_f = 6.12*(10^(-7));
D_m = 9*(10^(-6)); 
D_p = 9*(10^(-6))/37;
chi_f = 6.12*(10^(-7))*10/3;
delta_c = 0.001; % Estimate
delta_f = 0.005; 
delta_m = 0.009; 
delta_p = 0.1925;

sigma_c = 0.018;
c_0 = 0.1; % Estimate
f_max = 50; % Estimate
k_f = 30; %Estimate
gamma_f = 0.05; % Estimate
m_thresh = 5*10^(-9); % Estimate
eta = 1.08*10^(6);
sigma_f = 0.0385;
f_0 = 0.12;
k_m = 4*2.9*10^(-10);
gamma_m = 0.05; % Estimate
mu = 4.98*10^(8)/24; 
k_p = 3.86*10^(-2); % Estinate
gamma_p = 0.05; % Estimate

sigma_C = f_0/c_0;
eta_bar = eta*m_thresh/sigma_c;
delta_C = delta_c/sigma_c;
D_F = D_f/D_c;
chi_F = chi_f/D_c;
sigma_F = sigma_f/sigma_c;
gamma_F = gamma_f/c_0;
delta_F = delta_f/sigma_c;
D_M = D_m/D_c;
k_M = k_m/(m_thresh*sigma_c);
gamma_M = gamma_m/f_0;
mu_bar = mu*m_thresh/sigma_c;
delta_M = delta_m/sigma_c;
D_P = D_p/D_c;
k_P = k_p/sigma_c;
gamma_P = gamma_p/f_0;
delta_P = delta_p/sigma_c;
dummy = 1;


y0=1;
time_points = 1;


% % Variables Labels
% y_var_label={'T','T*','T**','V'};
