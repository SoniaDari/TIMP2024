%% This ODE represents the HIV model in Section 4.2
function dydt=ODE_efast_maxMMP(X,run_num)

%% PARAMETERS %%
Parameter_settings_EFAST;

sigma_C=X(run_num,1);
f_max=X(run_num,2);
eta_bar=X(run_num,3);
delta_C=X(run_num,4);
D_F=X(run_num,5);
chi_F=X(run_num,6);
sigma_F=X(run_num,7);
delta_F=X(run_num,8);
D_M=X(run_num,9);
k_M=X(run_num,10);
gamma_M=X(run_num,11);
mu_bar=X(run_num,12);
delta_M=X(run_num,13);
D_P=X(run_num,14);
k_P=X(run_num,15);
gamma_P=X(run_num,16);
delta_P=X(run_num,17);
k_f=X(run_num,18);
gamma_F=X(run_num,19);
dummy=X(run_num,20);

q = 0;
r = 100;
nx = 100;
x=linspace(q,r,nx);
delta_x = x(2)-x(1);
tspan = linspace(0,20,20);

C_init = heaviside(3-x);
F_init = heaviside(3-x);
M_init = 0.1*exp(-((x-3).^2));
P_init = 0*ones(1,nx);
u0 = [C_init F_init M_init P_init];

[t,u] = ode15s(@(t,y) fourvariablemodelnondim_nonlinearity(t,y,nx,delta_x,...
    sigma_C,f_max,eta_bar,delta_C,D_F,chi_F,sigma_F,delta_F,D_M,k_M,gamma_M,...
    mu_bar,delta_M,D_P,k_P,gamma_P,delta_P,k_f,gamma_F),tspan, u0);
    T = u(:,3*nx+1:4*nx);
    T_20 = T(20,:);
    sensitivity_metric = max(T_20(1,:));
    dydt = sensitivity_metric;

end
