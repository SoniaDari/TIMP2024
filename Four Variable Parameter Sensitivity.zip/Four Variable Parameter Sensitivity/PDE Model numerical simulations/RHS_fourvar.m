% defines the RHS for the ode solver

function dx=RHS_fourvar(~,u,p)

    C = u(1:p.Nx);
    F = u(p.Nx+1:2*p.Nx);
    M = u(2*p.Nx+1:3*p.Nx);
    P = u(3*p.Nx+1:4*p.Nx);
    
    dC = p.Jac(1:p.Nx,1:p.Nx)*C + p.sigma_C.*F.*(1-C).*(1+p.f_max.*M.*exp(1-M))-p.eta_bar.*M.*C-p.delta_C.*C;
    dF = p.Jac(p.Nx+1:2*p.Nx,p.Nx+1:2*p.Nx)*F + p.sigma_F.*F.*(1-F).*(1+(p.k_f.*C./(p.gamma_F+C))) - p.delta_F.*F;
    dM = p.Jac(2*p.Nx+1:3*p.Nx,2*p.Nx+1:3*p.Nx)*M + (p.k_M.*F).*(1-C)./(p.gamma_M+F) - p.mu_bar.*M.*P - p.delta_M.*M;
    dP = p.Jac(3*p.Nx+1:4*p.Nx,3*p.Nx+1:4*p.Nx)*P + p.k_P.*F.*M./(p.gamma_P+F) - p.mu_bar.*M.*P - p.delta_P.*P;
    
    dx	= [dC;dF;dM;dP];
