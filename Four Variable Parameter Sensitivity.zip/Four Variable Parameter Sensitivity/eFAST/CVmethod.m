function [CVsi CVsti]=CVmethod(Si, rangeSi,Sti,rangeSti,out)
meanSi=[];
meanSti=[];
[k s NR u]=size(rangeSi);
u;
if u==1
    out=1;
    for j=1:k
        for t=1:s
            meanSi(j,out)=(mean(rangeSi(j,:,out)));
            meanSti(j,out)=(mean(rangeSti(j,:,out)));
            stdSi(j,out)=(std(rangeSi(j,:,out)));
            stdSti(j,out)=(std(rangeSti(j,:,out)));
        end
    end
    a=Si(:,:,out)./meanSi(:,:,out);
    b=Sti(:,:,out)./meanSti(:,:,out);
else
    for j=1:k
        for t=1:s
            meanSi(j,out)=squeeze(mean(rangeSi(j,:,out)));
            meanSti(j,out)=squeeze(mean(rangeSti(j,:,out)));
            stdSi(j,out)=squeeze(std(rangeSi(j,:,out)));
            stdSti(j,out)=squeeze(std(rangeSti(j,:,out)));
        end
    end
a=stdSi(:,out)./meanSi(:,out);
b=stdSti(:,out)./meanSti(:,out);
    %a=Si(:,:,out)./meanSi(:,:,out)
    %b=Sti(:,:,out)./meanSti(:,:,out)
end
%for i=1:k
%    for t=1:s
%        CVsi(i,t)=std(a(i,t))/mean(a(i,t));
%        CVsti(i,t)=std(b(i,t))/mean(b(i,t));
%    end
%end

CVsi=100*a'
CVsti=100*b'