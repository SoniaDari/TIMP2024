function mybarplot(Si,Sti)

efast_var_hor={'$\sigma_C$','$f_{max}$','$\overline{\eta}$','$\delta_C$','$D_F$','$\chi_F$'...
    '$\sigma_F$','$\delta_F$','$D_M$','$k_M$','$\gamma_M$',...
    '$\overline{\mu}$','$\delta_M$','$D_P$','$k_P$','$\gamma_P$','$\delta_P$','$k_f$','$\gamma_F$','dummy'};
        

l = size(Si,1);
x = 1:l;
    
    for j = 1:size(Si,2)

    figure()
    y1 = Si(:,j);
    y2 = Sti(:,j);
    y = [y1, y2];
    h = bar(x, y);
    set(gcf,'Position', [10 10 800 500]);
    legend(h,{'First Order','Total Order'})
    ylim([0 1])
    xticks(1:20)
    xticklabels(efast_var_hor)
    ylabel('eFAST Sensitivity','Fontsize',22')
    xlabel('Parameter','Fontsize',22')
    shg

    fig = gcf;  % Get the current figure handle
    filename = 'my_plot.fig';  % Specify the filename with .fig extension
    saveas(fig, filename);
    
    end


end