%% This ODE represents the HIV model in Section 4.2
function dydt=ODE_efast_wavespeed(X,run_num)

%% PARAMETERS %%
Parameter_settings_EFAST;

sigma_C=X(run_num,1);
f_max=X(run_num,2);
eta_bar=X(run_num,3);
delta_C=X(run_num,4);
D_F=X(run_num,5);
chi_F=X(run_num,6);
sigma_F=X(run_num,7);
delta_F=X(run_num,8);
D_M=X(run_num,9);
k_M=X(run_num,10);
gamma_M=X(run_num,11);
mu_bar=X(run_num,12);
delta_M=X(run_num,13);
D_P=X(run_num,14);
k_P=X(run_num,15);
gamma_P=X(run_num,16);
delta_P=X(run_num,17);
k_f=X(run_num,18);
gamma_F=X(run_num,19);
dummy=X(run_num,20);

q = 0;
r = 100;
nx = 100;
x=linspace(q,r,nx);
delta_x = x(2)-x(1);
tspan = linspace(0,20,20);

C_init = heaviside(3-x);
F_init = heaviside(3-x);
M_init = 0.1*exp(-((x-3).^2));
P_init = 0*ones(1,nx);
u0 = [C_init F_init M_init P_init];

options = odeset('Events',@wavespeed_events_fourvar);

[t,u,te,ye,ie] = ode15s(@(t,y) fourvariablemodelnondim_nonlinearity(t,y,nx,delta_x,...
    sigma_C,f_max,eta_bar,delta_C,D_F,chi_F,sigma_F,delta_F,D_M,k_M,gamma_M,...
    mu_bar,delta_M,D_P,k_P,gamma_P,delta_P,k_f,gamma_F),tspan, u0,options);
    IE = ie<=100;
    index = find(IE==1);
    te_ECM = te(index);
    if size(index) == 0
        e1 = 0;
    elseif size(index)<nx
        c1 = ((r-q)/nx)./diff(te_ECM);
        N = 3;
        NN = floor(length(c1)/N);
        d1 = c1(NN+1:2*NN+1);
        e1 = mean(d1);
    elseif size(index)<2*nx
        c1 = ((r-q)/nx)./diff(te_ECM(1:2:end));
        N = 3;
        NN = floor(length(c1)/N);
        d1 = c1(NN+1:2*NN+1);
        e1 = mean(d1);
    elseif size(index)<3*nx
        c1 = ((r-q)/nx)./diff(te_ECM(1:3:end));
        N = 3;
        NN = floor(length(c1)/N);
        d1 = c1(NN+1:2*NN+1);
        e1 = mean(d1);        
    else 
        e1 = 1;
    end
    sensitivity_metric = e1;
    dydt = sensitivity_metric;



end
