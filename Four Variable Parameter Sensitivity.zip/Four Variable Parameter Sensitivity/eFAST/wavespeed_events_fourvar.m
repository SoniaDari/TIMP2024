function [value,isterminal,direction] = wavespeed_events_fourvar(t,u)

value       = u(1:end)-0.05;
isterminal  = [0*u(1:end-1);0.99];
direction   = 0*u;

end